import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-team3',
  templateUrl: './team3.component.html',
  styleUrls: ['./team3.component.css']
})
export class Team3Component implements OnInit {

  constructor() { }

  ngOnInit() {
  }

}
