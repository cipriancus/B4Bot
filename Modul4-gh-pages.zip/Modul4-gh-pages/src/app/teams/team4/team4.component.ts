import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-team4',
  templateUrl: './team4.component.html',
  styleUrls: ['./team4.component.css']
})
export class Team4Component implements OnInit {

  constructor() { }

  ngOnInit() {
  }

}
