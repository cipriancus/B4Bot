import {Component, OnInit, ElementRef, ViewChild} from '@angular/core';
import { ChatBotService } from "../Services/chat-bot.service";
import {Observable} from 'rxjs/Observable';

@Component({
  selector: 'app-chatbot',
  templateUrl: './chatbot.component.html',
  styleUrls: ['./chatbot.component.css']
})
export class ChatbotComponent implements OnInit {
  private chat: any[];
  private statement: string;
  @ViewChild('footer')footer:ElementRef;
  constructor( private chatService: ChatBotService,myElement: ElementRef) {

  }
//joy anger fear disgust sadness
  ngOnInit() {
    console.log(new Date());

    this.statement = "Send me a message!";
    this.chat = JSON.parse(localStorage.getItem('chat'));
    if (this.chat != null && this.chat.length>100)
      localStorage.setItem("chat",null);
    if (this.chat == null) {
      this.chat=[['Hello!','bot','joy']];
    }
    localStorage.setItem('chat', JSON.stringify(this.chat));
    console.log(this.chat);
    
  }

  // ngAfterViewInit() {
  //   console.log(this.footer.nativeElement.value);
  // }
  SentStatement(stat) {
    var statement=stat.value
    stat.value = ''
    console.log(statement);
    localStorage.setItem('chat', JSON.stringify(this.chat));
    this.chat.push([statement,'user',this.chat[length][2]]);
    this.chatService.postStatement(statement).subscribe(
        data=> {
          console.log(data.json().response);
          this.chat.push([data.json().response,'bot',data.json().emotion]);
          localStorage.setItem('chat', JSON.stringify(this.chat));
        },
        error => console.log('++++'+"Error: " + error+'+++++++')

      );

  }

}
