import {Injectable} from '@angular/core';
import {RequestOptions, Http, Headers} from "@angular/http";


@Injectable()
export class ChatBotService {
    chat_bot_link = "http://46.32.233.88:5000/api/bot";

    constructor(private _http: Http) {
    }

    postStatement(statement) {
        let opt: RequestOptions;
        let myHeaders: Headers = new Headers;
        myHeaders.set('Access-Control-Allow-Origin', '*');
        myHeaders.append('Content-type', 'application/json');
        var body = {
            "statement": statement
        };
        opt = new RequestOptions({
            headers: myHeaders
        });

        return this._http.post(this.chat_bot_link, body, opt);
    }

}
