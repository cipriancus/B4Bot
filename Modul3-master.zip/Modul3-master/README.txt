This is Module 3.

ChatBot Dev - Modulul 3 

Saptamana 1


Lavinia Tiba & Antonia Bursuc - Sinonimele unui cuvant si transformarea lor in lista + Corector gramatical

Cu ajutorul functiei synset din libraria Wordnet se obtin sinonimele unui cuvant. Avand lista synonyms cu ajutorul unui for luam fiecare sinonim al cuvantului si-l adaugam in forma corecta cu ajutorul functiei lemmas in lista respectiva.

Exemplu: pentru cuvantul �good� se afiseaza:

synonyms = {'beneficial', 'just', 'upright', 'thoroughly', 'in_force', 'well', 'skilful', 'skillful', 'sound', 'unspoiled', 'expert', 'proficient', 'in_effect', 'honorable', 'adept', 'secure', 'commodity', 'estimable', 'soundly', 'right', 'respectable', 'good', 'serious', 'ripe', 'salutary', 'dear', 'practiced', 'goodness', 'safe', 'effective', 'unspoilt', 'dependable', 'undecomposed', 'honest', 'full', 'near', 'trade_good', 'evil', 'evilness', 'bad', 'badness', 'ill'}.

Inputul introdus de user poate fi corectat din doua puncte de vedere: 
1. Spelling correction - se foloseste libraria TextBlob pentru a rescrie fiecare cuvant in forma ce se presupune a fi corecta
2. Grammar correction -  se foloseste libraria language-check pentru corectarea textului din punct de vedere al regulilor gramaticale
 

Source Code Sinonime & Corector gramatical(inca nu e integrat total)



Cadaru Lucian - Identificare limba & Tokenizare propozitii

Using the Python module langid , the function lang_identify tests if the language of a given text is in english or not.  
Using NTLK module, the function sentenceTokenizer splits a text returning a list of sentences.

Source Code Identificator limba & Tokenizer



Cosmin Cotoc & Corciu Mihai - Identificare relatiilor dintre cuvinte in cadrul propozitiei si partile de vorbire de care apartin acestea

 Am utilizat clasa StanfordDependencyParser din package-ul nltk.stanford pentru a extrage relatiile si partile de vorbire. Datele sunt stocate sub format json generat dintr-un dictionar ce contine informatiile obtinute cu parserul de dependente.

Source Code

Fisier JSON

To dos: adaugat lemma, creare client care sa simuleze conexiune externa, hypernyms,  corectare gramaticala(mai multe variante sau nu), posibilitate pentru fiecare cuvant in parte, mecanism corectare raspuns bot.

RASPUNS BOT: corectare si variatie raspuns



Saptamana 2


Lavinia Tiba - lemma si hypernyms - in curs de implementare. Lemmatizarea nu avea loc pentru verbe deoarece metoda din wornet are nevoie de un flag setat pentru a sti ca partea de vorbire care urmeaza sa o analizeze este un verb. Incerc sa implementez o functie care sa se foloseasca de informatiile extrase cu ajutorul parserului de dependente.

Antonia Bursuc - avansare corectare si verificare gramaticala. Corectarea se face in functie de contextul propozitiei. Din pacate, modulul de sugestii(sugestions in fisierul JSON) fa afisa null deoarece operatiile se fac pe propozitia deja corectata din punct de vedere gramatical.

Lucian Cadaru - modificare codului in care se tokenizeaza propozitiile (acum se returneaza cu tot cu semn). Semnul este inregistrat in dictionar sub variabila �punctuation� luand ultimul caracter din propozitie.

Cotoc Cosmin & Corciu Mihai - implementarea serverului propriu-zis. Serverul primeste clientii si ii manageriaza utilizand thread-uri. Pentru fiecare client se creeaza un nout thread, in care se efectueaza operatiile de verificare a limbajului, de corectare a textului si trecerea fiecarei propozitii prin parserul de dependente (dependency parser). Atunci cand se ajunge la parsarea tuplelor, se utilieaza din nou thread-uri, care vor modifica dictionarul in care se inregistreaza datele utilizand un mecanism de blocare a resurselor(Rlock).

Saptamana finala

Modulul a fost implementat in proiectul principal. Vedeti codul sursa al proiectului.